// Clean main.ts - HTML content is in index.html
